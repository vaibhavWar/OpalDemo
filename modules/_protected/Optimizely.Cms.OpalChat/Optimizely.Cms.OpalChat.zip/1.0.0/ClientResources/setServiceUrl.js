﻿const optiOpalContextRoot = document.getElementsByTagName(
    "opti-opalchat-context",
)[0];

const serviceUrl = optiOpalContextRoot?.getAttribute("serviceUrl") ?? "";
if (serviceUrl) {
    localStorage.setItem("ai-chat:BASE_URL", serviceUrl);
} else {
    console.error("Opal Chat Service URL is missing");
}
